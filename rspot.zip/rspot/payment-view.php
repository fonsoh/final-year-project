<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['hbmsuid']==0)) {
  header('location:logout.php');
  } else{
      
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Campsite and Campgear Booking System | Hotel :: View Booking Detail</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/responsiveslides.min.js"></script>
 <script>
    $(function () {
      $("#slider").responsiveSlides({
      	auto: true,
      	nav: true,
      	speed: 500,
        namespace: "callbacks",
        pager: true,
      });
    });
  </script>

  <style>
    .img-placeholder{
      width: 300px;
      height: 300px;
      margin-bottom: 1.5em;
      border: 1px solid gray;
      background-color: gray;
    }
  </style>

</head>
<body>
		<!--header-->
      <div class="header head-top">
				<div class="container">
	      <?php include_once('includes/header.php');?>
		    </div>
      </div>

      <div class="typography">
			<!-- container-wrap -->
        <div class="container">
            <div class="typography-info">
              <h2 class="type">My Ticket Booking Detail</h2>
            </div>
            <div class="row" style="display:flex; justify-content:center; gap: 10px; padding-top:20px;">
              <div class="img-placeholder" style="background-image: url('../images/QR.png'); background-size: cover;"></div>
              <form action="../php/update-pay-status.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="bookingNumber" value="<?php echo $_GET['invid'] ?>"/>
                <input type="file" class="form-control-file" id="receiptFileInput" name="receipt" accept="image/*" />
                <button type="submit" class="btn btn-primary" style="margin-top:10px;">Submit</button>
              </form>
            </div>
        </div>
      </div>

			<?php include_once('includes/getintouch.php');?>
			<!--footer-->
			<?php include_once('includes/footer.php');?>
</body>
</html><?php }  ?>
