<?php
    include('../includes/dbconnection.php');

    $bookingNum = $_POST['bookingNumber'];

    // Prepare and execute the SQL statement
    try {
        $stmt = $dbh->prepare("UPDATE tblbooking SET paymentStatus ='Paid' WHERE BookingNumber=:bookingNumber");
        $stmt->bindParam(':bookingNumber', $bookingNum, PDO::PARAM_STR);
        $stmt->execute();

        // Check if the update was successful
        $affectedRows = $stmt->rowCount();
        if ($affectedRows > 0) {
            // Redirect to another page after successful update
            header("Location: ../my-booking.php");
            exit(); // Ensure that no further code is executed after the redirect
        } else {
            echo "No records updated. Invalid booking number: $bookingNum";
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
?>